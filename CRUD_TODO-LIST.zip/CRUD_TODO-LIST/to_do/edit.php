<?php

$user_id = $_REQUEST["id"];

$user_id;

include("connections.php");

$get_record = mysqli_query($connections, "SELECT * FROM my_tbl1 WHERE id='$user_id'");

while($row_edit = mysqli_fetch_assoc($get_record)) {
	
	$db_time = $row_edit["time"];
    $db_note = $row_edit["note"];
    $db_date = $row_edit["date"];
        
	
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="style.css">
    <style>
    
    .form2{
  grid-column: 2/4;
  grid-row: 2/4;
  background-color: #FAAB78;
  border-radius: 7px;
  padding: 5px;
}

</style>
</head>
<body>
    
<div id="container">
    <div class="nav">
            <h1>To-do List</h1>
            
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            
           
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item active">
                                <a class="nav-link" href="home.html">Home <span class="sr-only"></span></a>
                        </li>
                        <li class="nav-item">
                                <a class="nav-link" href="index2.php">Today's</a>
                        </li>
                        <li class="nav-item">
                                <a class="nav-link" href="index1.php">This Week's</a>
                        </li>
                    </ul>
            </div>
        </nav>
            
    </div> 
<div class="form2">
<h2>Edit your note</h2>
<form method="POST" action="Update_Record.php">

<input type="hidden" name="user_id" value="<?php echo $user_id; ?>">

<input type="text" name="new_time" value="<?php echo $db_time; ?>">
<input type="text" name="new_note" value="<?php echo $db_note; ?>">
<input type="text" name="new_date" value="<?php echo $db_date; ?>">
<br>
<br>


<input type="submit" value="Update" style="padding: top 5px;">

</form>
<br>
</div>

<br>
<br>
<br>
<footer>
        
        
        <p style="color:white; padding-right:70%; font-size:200%;"><b>To-do List</b></p>
        <p style="padding-left:10%;">Author: Kyle Omega<br>
        <a href="Gmail:omega.kyle@gmail.com">omega.kyle@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Shane Ruiz<br>
        <a href="Gmail:shane.ruiz@gmail.com">shane.ruiz@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Justine Pascual<br>
        <a href="Gmail:pascual.justine@gmail.com">pascual.justine@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Siti Othman<br>
        <a href="Gmail:othman.siti@gmail.com">othman.siti@gmail.com</a></p>
        
        

    </footer>
    <div class="about">
        <p><b>About</b></p>
        <p>This website will help you accomplish your task by listing your activities
            and become more productive. </p>
    </div>
    
 </div>     
</body>
</html>