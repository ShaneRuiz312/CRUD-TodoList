<?php

include("connections2.php");

$user_id = $_POST["user_id"];
$new_time = $_POST["new_time"];
$new_note = $_POST["new_note"];


mysqli_query($connections2, "UPDATE my_tbl2 SET time='$new_time', note='$new_note' WHERE id='$user_id'");

echo "<script>alert('Record has been updated!');</script>";
echo "<script>window.location.href='index2.php';</script>";

?>
