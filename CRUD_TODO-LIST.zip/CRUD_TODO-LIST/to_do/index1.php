
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>
    <link rel="stylesheet" href="bootstrap-5.1.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">



</head>
<body>

<?php

$time = $note = $date = "";
$timeErr = $noteErr = $dateErr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["time"])) {
        $timeErr = "Time is required!";
    } else {
        $time = $_POST["time"];
    }

    if (empty($_POST["note"])) {
        $noteErr = "Note is required!";
    } else {
        $note = $_POST["note"];
    }

    if (empty($_POST["date"])) {
        $dateErr = "Date is required!";
    } else {
        $date = $_POST["date"];
    }
}
?>


<div id="container">
    <div class="nav">
            <h1>To-do List</h1>
            
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            
           
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item active">
                                <a class="nav-link" href="login2.php" style="color:red;">Logout <span class="sr-only"></span></a>
                        </li>
                        <li class="nav-item">
                                <a class="nav-link" href="index2.php">Today's</a>
                        </li>
                        <li class="nav-item">
                                <a class="nav-link" href="index1.php">This Week's</a>
                        </li>
                    </ul>
            </div>
        </nav>
            
    </div> 

<br>
<br>



<div class="form">
    <div class="form-bg">
        <h1>
            This Week's Goals
        </h1>
                <form class="rounded-9" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <p>Time</p>
                    <input type="text" name="time" value="<?php echo $time; ?>"> <br>
                    <span class="error"><?php echo $timeErr; ?></span> <br>

                    <p>Note</p>
                    <input type="text" name="note" class="note_field" value="<?php echo $note; ?>"> <br>
                    <span class="error"><?php echo $noteErr; ?></span> <br>

                    <p>Date</p>
                    <input type="text" name="date" value="<?php echo $date; ?>"> <br>
                    <span class="error"><?php echo $dateErr; ?></span> <br>

                    <input class="input" type="submit" value="SUBMIT">
                </form>
    </div>
</div>            
<div class="result">
                <h3>Goals</h3>

                <?php
                include("connections.php");
                if ($time && $note && $date) {
                    $query = mysqli_query($connections, "INSERT INTO my_tbl1(time,note,date) VALUES('$time','$note','$date')");

                    echo "<script language='javascript'>alert('New Record has been inserted!')</script>";
                    echo "<script>window.location.href='index1.php';</script>";
                }

                $view_query = mysqli_query($connections, "SELECT * FROM my_tbl1");

                if (mysqli_num_rows($view_query) > 0) {
                    echo "<table>";
                    echo "<tr>
                            <th>TIME</th>
                            <th>NOTE</th>
                            <th>DATE</th>
                            <th>OPTION</th>
                        </tr>";

                    while ($row = mysqli_fetch_assoc($view_query)) {

                            $user_id = $row["id"];
	
                            $db_time = $row["time"];
                            $db_note = $row["note"];
                            $db_date = $row["date"];
                           
                        echo "<tr>
                             
                            <td>".$row['time']."</td>
                            <td>".$row['note']."</td>
                            <td>".$row['date']."</td>
                            
                            <td>
                            <button type='button'><a style='float:left' href='edit.php?id= $user_id'>Update</a></button>
                            <button type='button'><a style='float:right' href='Confirm_Delete.php?id= $user_id'>Delete</a></button>
                            </td>			
				            </tr>";		
				  	
                            
                    }

                    echo "</table>";
                } else {
                    echo "No goals found.";
                }
                ?>
    </div>
    
    <footer>
        
        
        <p style="color:white; padding-right:70%; font-size:200%;"><b>To-do List</b></p>
        <p style="padding-left:10%;">Author: Kyle Omega<br>
        <a href="Gmail:omega.kyle@gmail.com">omega.kyle@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Shane Ruiz<br>
        <a href="Gmail:shane.ruiz@gmail.com">shane.ruiz@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Justine Pascual<br>
        <a href="Gmail:pascual.justine@gmail.com">pascual.justine@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Siti Othman<br>
        <a href="Gmail:othman.siti@gmail.com">othman.siti@gmail.com</a></p>
        
        

    </footer>
    <div class="about">
        <p><b>About</b></p>
        <p>This website will help you accomplish your task by listing your activities
            and become more productive. </p>
    </div>
    
 </div>     

 <script src="bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
