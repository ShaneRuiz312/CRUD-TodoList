<?php

include("connections.php");

$user_id = $_POST["user_id"];
$new_time = $_POST["new_time"];
$new_note = $_POST["new_note"];
$new_date = $_POST["new_date"];

mysqli_query($connections, "UPDATE my_tbl1 SET time='$new_time', note='$new_note', date='$new_date' WHERE id='$user_id'");

echo "<script>alert('Record has been updated!');</script>";
echo "<script>window.location.href='index1.php';</script>";

?>
