<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Registration Form</title>
    <link rel="stylesheet" href="style.css">
<style>
        body{
            background-color: #473C33 ;
        }
        .form2{
            grid-column: 2/4;
            grid-row: 2/4;
            background-color: #FAAB78;
            border-radius: 7px;
            padding:5px;
            margin-left:auto;
            margin-right:auto;
            }
            .nav{
            grid-column: 1/6;
            background-color: #FFFBAC;
            margin-top: 0;
            margin-bottom: 5%;
            border-radius: 10px;
            padding:10px;
        }
        input[type=email], select, textarea {
            width: auto;
            padding: 12px;
            border: 1px solid black;
            border-radius: 10px;
            box-sizing: border-box;
            margin-top: 6px;
            margin-bottom: 0px;
     
  }
        input[type=password], select, textarea {
            width: auto;
            padding: 12px;
            border: 1px solid black;
            border-radius: 10px;
            box-sizing: border-box;
            margin-top: 6px;
            margin-bottom: 0px;
     
  }
  input[type=text], select, textarea {
            width: auto;
            padding: 12px;
            border: 1px solid black;
            border-radius: 10px;
            box-sizing: border-box;
            margin-top: 6px;
            margin-bottom: 0px;
     
  }
</style>

</head>

<body>
<?php
$name = $email = $userPassword = "";
$nameErr = $emailErr = $passwordErr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["name"])) {
        $nameErr = "Name is required!";
    } else {
        $name = $_POST["name"];
    }

    if (empty($_POST["email"])) {
        $emailErr = "Email is required!";
    } else {
        $email = $_POST["email"];
    }

    if (empty($_POST["password"])) {
        $passwordErr = "Password is required!";
    } else {
        $userPassword = $_POST["password"];
    }

    $servername = "localhost";
    $username = "root";
    $dbPassword = ""; 
    $dbname = "registration_form";

    $connection = mysqli_connect($servername, $username, $dbPassword, $dbname);

    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $hashedPassword = password_hash($userPassword, PASSWORD_DEFAULT);

    if ($name && $email && $userPassword) {
        $query = "INSERT INTO register (name, email, `password`) VALUES ('$name', '$email', '$hashedPassword')";
        if (mysqli_query($connection, $query)) {
            echo "<script>alert('Registration successful!')</script>";
            echo "<script>window.location.href='login2.php';</script>";
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($connection);
        }
    }

    mysqli_close($connection);
}
?>
<div class="nav">
            <h1>To-do List</h1>
            
</div> 


<div class="container">
    <div class="form2">
        <h3>Register</h3>
        <form class="rounded-9" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <p>Name</p>
            <input type="text" name="name" value="<?php echo $name; ?>"> <br>
            <span class="error"><?php echo $nameErr; ?></span> <br>

            <p>Email</p>
            <input type="email" name="email" value="<?php echo $email; ?>"> <br>
            <span class="error"><?php echo $emailErr; ?></span> <br>

            <p>Password</p>
            <input type="password" name="password"> <br>
            <span class="error"><?php echo $passwordErr; ?></span> <br>

            <input class="input" type="submit" value="Register">
        </form>
    </div>
    <br>
    <br>
    <br>
    <footer>
        
        
        <p style="color:white; padding-right:70%; font-size:200%;"><b>To-do List</b></p>
        <p style="padding-left:10%;">Author: Kyle Omega<br>
        <a href="Gmail:omega.kyle@gmail.com">omega.kyle@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Shane Ruiz<br>
        <a href="Gmail:shane.ruiz@gmail.com">shane.ruiz@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Justine Pascual<br>
        <a href="Gmail:pascual.justine@gmail.com">pascual.justine@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Siti Othman<br>
        <a href="Gmail:othman.siti@gmail.com">othman.siti@gmail.com</a></p>
        
        

    </footer>
</div>
    <script src="bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
