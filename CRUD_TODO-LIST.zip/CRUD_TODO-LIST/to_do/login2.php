<?php
session_start();

$email = $password = "";
$emailErr = $passwordErr = "";
$loginError = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["email"])) {
        $emailErr = "Email is required!";
    } else {
        $email = $_POST["email"];
    }

    if (empty($_POST["password"])) {
        $passwordErr = "Password is required!";
    } else {
        $password = $_POST["password"];
    }

    $servername = "localhost";
    $username = "root";
    $dbPassword = "";
    $dbname = "registration_form";

    $connection = mysqli_connect($servername, $username, $dbPassword, $dbname);

    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $query = "SELECT password FROM register WHERE email = '$email'";
    $result = mysqli_query($connection, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $storedPassword = $row["password"];

        if (password_verify($password, $storedPassword)) {
            $_SESSION["email"] = $email;
            header("Location: index1.php");
            exit();
        } else {
            $loginError = "Invalid email or password";
        }
    } else {
        $loginError = "Invalid email or password";
    }

    mysqli_close($connection);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login Form</title>
    
    <link rel="stylesheet" href="style.css">
    <style>
        body{
            background-color: #473C33;
        }
        .form2{
            grid-column: 2/4;
            grid-row: 2/4;
            background-color: #FAAB78;
            border-radius: 7px;
            padding:5px;
            margin-left:auto;
            margin-right:auto;
            }
            .nav{
            grid-column: 1/6;
            background-color: #FFFBAC;
            margin-top: 0;
            margin-bottom: 5%;
            border-radius: 10px;
            padding:10px;
        }
        input[type=email], select, textarea {
                width: auto;
                padding: 12px;
                border: 1px solid black;
                border-radius: 10px;
                box-sizing: border-box;
                margin-top: 6px;
                margin-bottom: 0px;
     
  }
  input[type=password], select, textarea {
                width: auto;
                padding: 12px;
                border: 1px solid black;
                border-radius: 10px;
                box-sizing: border-box;
                margin-top: 6px;
                margin-bottom: 0px;
     
  }

                </style>
</head>
<body>
    <div class="container">
    <div class="nav">
            <h1>To-do List</h1>
            
    </div> 


    <div class="form2">
        <h3>Login</h3>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <p>Email</p>
            <input type="email" name="email" value="<?php echo $email; ?>"> <br>
            <span class="error"><?php echo $emailErr; ?></span> <br>

            <p>Password</p>
            <input type="password" name="password"> <br>
            <span class="error"><?php echo $passwordErr; ?></span> <br>
            <span class="error"><?php echo $loginError; ?></span> <br>

            <input class="input" type="submit" value="Login">

            <p> Don't have an account?<a href="register.php"> Register here</a></p>

        </form>
    </div>
    <br>
    <br>
    <br>
    <footer>
        
        
        <p style="color:white; padding-right:70%; font-size:200%;"><b>To-do List</b></p>
        <p style="padding-left:10%;">Author: Kyle Omega<br>
        <a href="Gmail:omega.kyle@gmail.com">omega.kyle@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Shane Ruiz<br>
        <a href="Gmail:shane.ruiz@gmail.com">shane.ruiz@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Justine Pascual<br>
        <a href="Gmail:pascual.justine@gmail.com">pascual.justine@gmail.com</a></p>
        <p style="padding-left:10%;">Author: Siti Othman<br>
        <a href="Gmail:othman.siti@gmail.com">othman.siti@gmail.com</a></p>
        
        

    </footer>
</div>
    <script src="bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
