<?php

include("connections2.php");

$user_id = $_POST["user_id"];

mysqli_query($connections2, "DELETE FROM my_tbl2 WHERE id = '$user_id' ");


echo "<script language='javascript'>alert('Record has been Deleted!')</script>";
echo "<script>window.location.href='index2.php';</script>";
?>