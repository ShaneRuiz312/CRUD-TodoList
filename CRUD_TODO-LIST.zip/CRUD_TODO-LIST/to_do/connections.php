<?php

$connections = mysqli_connect("localhost","root","","todo");
if (mysqli_connect_errno()){
	echo "Failed to connect to Mysql: ". mysqli_connect_error();
}


?>