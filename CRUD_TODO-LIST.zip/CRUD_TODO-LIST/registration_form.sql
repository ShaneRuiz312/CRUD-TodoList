-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2023 at 02:38 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `email`, `password`) VALUES
(2, 'shane ruiz', 'shane@gmail.com', '$2y$10$9L4JsQjTxGxi8v6biy8qKuFtF1Jm1PyTySuwycpYUkfvA.zATCSBy'),
(3, 'shane ruiz', 'tracy.ruiz14@yahoo.com', '$2y$10$H87.wn/pwvHHrRa61EUkdOs0ixp.MJ8vhG/jQ.UMeP8Rqo2prtjC6'),
(4, 'shane', 'Shane.ruiz.dit.cvsu@gmail.com', '$2y$10$I4qyBdED3SCyXZty49Guaerp8c6YLheAeiPYQUkLD2cQQALKrczdC'),
(5, 'shane ruiz', 'shanethomas@gmail.com', '$2y$10$1LpQO6UUt78W022.Z1bcbui2jPCbu0QeP9F6V8OcWj2E39z0Kxg6q'),
(6, 'othmansiti', 'othmansiti@gmail.com', '$2y$10$XSf3.o.AnZOemC7fmj9n6e2/svGdvTOeyO3SMBHkf3FXJX.3cCtY.'),
(7, 'kai', 'kai@gmail.com', '$2y$10$3RGwXlTZWhofiU/uLidwOe5otVT2s9oHMcvRD4wkMkuWdCaNBpFmW');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
